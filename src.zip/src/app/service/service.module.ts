import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MyServiceComponent } from './my-service/my-service.component';
import { FormsModule } from '@angular/forms';




@NgModule({
  declarations: [
    MyServiceComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [
    MyServiceComponent
  ]
})
export class ServiceModule { }
