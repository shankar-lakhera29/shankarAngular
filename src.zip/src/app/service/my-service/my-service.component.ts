import { Component } from '@angular/core';
import { Post } from 'src/app/post.model';
import { MyServiceService } from "./../../my-service.service"

@Component({
  selector: 'app-my-service',
  templateUrl: './my-service.component.html',
  styleUrls: ['./my-service.component.scss']
})
export class MyServiceComponent {
 loadedPost: Post[] = [];
 isFetching = false;
  constructor(private myService:MyServiceService){}
  ngOnInit() {
    this.isFetching = true;
    this.myService.fetchPosts().subscribe(posts => {
      this.isFetching = false;
      this.loadedPost = posts;
    })
    
  }

  onCreatePost(postData: Post) {
    this.myService.createAndStorePost(postData.title, postData.content);
  }
  onFetchPost() {
    this.isFetching = true;
    this.myService.fetchPosts().subscribe(posts => {
      this.isFetching = false;
      this.loadedPost = posts;
    })
  }


}
