import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators'
import { Post } from 'src/app/post.model'

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {

  constructor( private http:HttpClient, ) { }

  createAndStorePost(title:string, content:string) {
    
    const postData: Post = {title: title, content: content}
    this.http.
    post<{name:string}>('https://mynewproject-d449d-default-rtdb.asia-southeast1.firebasedatabase.app/posts.json', postData).subscribe(myData =>{
      console.log(myData)
    })
    alert('hello');
  }
  fetchPosts() {
    return this.http.get<{ [key:string]: Post}>('https://mynewproject-d449d-default-rtdb.asia-southeast1.firebasedatabase.app/posts.json')
    .pipe(map(responseData => {
      const postsArrey = [];
      for(const key in responseData) {
        if(responseData.hasOwnProperty(key)){
        postsArrey.push({...responseData[key], id:key});
      }
    }
      return postsArrey;
    }))
  }

}
export { Post };

