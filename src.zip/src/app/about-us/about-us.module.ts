import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AboutUsComponent } from './about-us/about-us.component';
import { OurTeamComponent } from './our-team/our-team.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    AboutUsComponent,
    OurTeamComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [
    OurTeamComponent,
    AboutUsComponent
  ]
})
export class AboutUsModule { }
