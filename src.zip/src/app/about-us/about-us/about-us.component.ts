import { Component, OnDestroy, OnInit } from '@angular/core';
import { interval, Subscription, Observable } from 'rxjs';
import { map, filter } from 'rxjs/operators';
import { UserService } from 'src/app/user.service';
@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.scss']
})
export class AboutUsComponent implements OnInit, OnDestroy {
  private firstSubscription:any = Subscription;
  ngOnInit () {
    // this.firstSubscription = interval(1000).subscribe(count => {
    //   console.log(count);
    // })
    const customFirstObservable = new Observable(observer => {
      let count = 0;
      setInterval( () => {
        observer.next(count);
        if(count === 2) {
          observer.complete();
        }
        if(count > 3) {
          observer.error(new Error('count is greater then 3'))
        }
        count++;
      }, 1000) 
    });
    this.firstSubscription = customFirstObservable.pipe(filter( (myData: number) => {
      return myData > 0;
    }), map(myData => {
      return 'Round: ' + (myData + 1);
    })).subscribe(myData => {
      console.log(myData);
    }, error => {
      console.log(error);
      alert(error);
    }, () => {
      console.log('completed')
    })

  }
  ngOnDestroy(): void {
      this.firstSubscription.unsubscribe();
  }
  constructor(private myService: UserService) {}
  onActivated() {
    this.myService.activatedEmitter.next(true);
  }
}
