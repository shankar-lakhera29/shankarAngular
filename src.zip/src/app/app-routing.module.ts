import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us/about-us.component';
import { OurTeamComponent } from './about-us/our-team/our-team.component';

const routes: Routes = [
  {path:'about-us',
  component:AboutUsComponent
  },
  {path:'our-team',
  component:OurTeamComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
