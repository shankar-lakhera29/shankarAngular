import { Component, OnDestroy } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { map } from 'rxjs/operators';
import { UserService } from './user.service';




@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent {
  title = 'myNewProject';
  loadedPosts:any = [];
  userActivated = true;
  constructor( private http:HttpClient, private myService:UserService) {}
  private activaedSub:any = Subscription;
  ngOnInit() {
    this.fetchPosts();
    this.activaedSub = this.myService.activatedEmitter.subscribe(didactivate => {
      this.userActivated = didactivate;
    });
    }
    ngOnDestroy(): void {
      this.activaedSub.unsubscribe();
    }

  onCreatePost(postData: { title: string; content: string }) {
   this.http.post(
    'https://mynewproject-d449d-default-rtdb.asia-southeast1.firebasedatabase.app/posts.json', 
    postData).subscribe(responseMY => {
      console.log(responseMY);
    });
  }
  onFetchPosts() {
  this.fetchPosts();
}
onClearPosts() {

}
  private fetchPosts() {
    this.http.get(
      'https://mynewproject-d449d-default-rtdb.asia-southeast1.firebasedatabase.app/posts.json')
      .pipe(
        map(responseData => {
          const postsArray = [];
          for(const key in responseData) {
            if(responseData.hasOwnProperty(key)) {
              postsArray.push({...responseData[key], id:key});
            }
          }
          return postsArray;
        })
      )
      .subscribe(posts => {
        console.log(posts);
      }
      )
  }
  // private fetchPosts() {
  //   this.http.get(
  //     'https://mynewproject-d449d-default-rtdb.asia-southeast1.firebasedatabase.app/posts.json')
  //     .subscribe(posts => {
  //       console.log(posts);
  //     }
  //     )
  // }

}
